# SENTINELA RJ — Relatório de Anomalias
**Gerado em:** 02/06/2026  
**Fonte:** Portal Nacional de Contratações Públicas (PNCP)  
**Período da base:** 2023-03-20 → 2026-05-05  

---

## Visão Geral da Base

| Indicador | Valor |
|-----------|-------|
| Contratos analisados | 327 |
| Valor total | R$ 1,245,655,956.52 |
| Fornecedores distintos | 191 |
| Órgãos distintos | 4 |

**Distribuição por categoria:**

| Categoria | Contratos | Valor | % |
|-----------|-----------|-------|---|
| Serviços de Engenharia | 16 | R$ 715,299,470 | 57% |
| Obras | 28 | R$ 276,665,672 | 22% |
| Serviços | 97 | R$ 234,876,450 | 19% |
| Mão de Obra | 6 | R$ 8,961,968 | 1% |
| Compras | 174 | R$ 6,954,853 | 1% |
| Informática (TIC) | 4 | R$ 2,747,852 | 0% |
| Locação Imóveis | 1 | R$ 144,000 | 0% |
| Cessão | 1 | R$ 5,692 | 0% |

---

## Painel de Anomalias

🔴 **8** alta prioridade  
🟡 **4** prioridade média  
🟢 **28** baixa prioridade  
**Total:** 40 sinais detectados

| # | Score | Sev. | Tipo | Título |
|---|------:|------|------|--------|
| 1 | 0.891 | 🔴 | Inexigibilidade | Inexigibilidade de licitação — R$ 45,000,000 — BONUS TRACK ENTRETENIME |
| 2 | 0.884 | 🔴 | Outlier de valor | Valor atípico — PRODUMIX COMERCIO E SERVICOS LTDA |
| 3 | 0.878 | 🔴 | Emergência | Contrato emergencial — R$ 12,928,979 — AZOS VIGILANCIA E SEGURANCA LTD |
| 4 | 0.873 | 🔴 | Dispensa | Dispensa de licitação — R$ 8,018,696 — MATRIZ CONSTRUCOES E SERVICOS E |
| 5 | 0.827 | 🔴 | Outlier de valor | Valor atípico — GAIA COMERCIO E PRODUTOS QUIMICOS LTDA |
| 6 | 0.820 | 🔴 | Concentração de fornecedor | Concentração: 4 contratos em 90 dias — CONSTRUTORA ENTRE OS RIOS LTDA |
| 7 | 0.796 | 🔴 | Outlier de valor | Valor atípico — PRONTO EXPRESS LOGISTICA SA |
| 8 | 0.777 | 🔴 | Outlier de valor | Valor atípico — BONUS TRACK ENTRETENIMENTO LTDA |
| 9 | 0.533 | 🟡 | Outlier de valor | Valor atípico — FARMACE - INDUSTRIA QUIMICO-FARMACEUTICA CEARENSE  |
| 10 | 0.520 | 🟡 | Outlier de valor | Valor atípico — MJRE CONSTRUTORA LTDA |
| 11 | 0.514 | 🟡 | Outlier de valor | Valor atípico — MINISTERIO DA JUSTICA E SEGURANCA PUBLICA |
| 12 | 0.500 | 🟡 | Outlier de valor | Valor atípico — SD ENGENHARIA LTDA |
| 13 | 0.350 | 🟢 | Inexigibilidade | Inexigibilidade de licitação — R$ 992,460 — EDITORA GLOBO S/A |
| 14 | 0.340 | 🟢 | Emergência | Contrato emergencial — R$ 389,610 — JRF MANUTENCAO E SERVICOS LTDA |
| 15 | 0.339 | 🟢 | Inexigibilidade | Inexigibilidade de licitação — R$ 350,000 — MITRA ARQUIEPISCOPAL DO RI |
| 16 | 0.335 | 🟢 | Inexigibilidade | Inexigibilidade de licitação — R$ 250,000 — ASSOCIACAO DOS MAGISTRADOS |
| 17 | 0.335 | 🟢 | Inexigibilidade | Inexigibilidade de licitação — R$ 257,250 — FORUS SOLUCOES EM SUSTENTA |
| 18 | 0.333 | 🟢 | Inexigibilidade | Inexigibilidade de licitação — R$ 212,013 — INSTITUTO DE EDUCACAO E SO |
| 19 | 0.330 | 🟢 | Inexigibilidade | Inexigibilidade de licitação — R$ 165,000 — PEERS SOLUCOES E SERVICOS  |
| 20 | 0.329 | 🟢 | Inexigibilidade | Inexigibilidade de licitação — R$ 144,000 — LYVIA DE MATOS AZEVEDO COR |
| 21 | 0.323 | 🟢 | Inexigibilidade | Inexigibilidade de licitação — R$ 85,000 — EMPRESA MUNICIPAL DE ARTES  |
| 22 | 0.312 | 🟢 | Inexigibilidade | Inexigibilidade de licitação — R$ 30,000 — PAD ROK PRODUCOES CULTURAIS |
| 23 | 0.312 | 🟢 | Dispensa | Dispensa de licitação — R$ 31,311 — IAGO BARBOSA DE SOUZA |
| 24 | 0.304 | 🟢 | Inexigibilidade | Inexigibilidade de licitação — R$ 15,000 — EMPRESA MUNICIPAL DE ARTES  |
| 25 | 0.277 | 🟢 | Dispensa | Dispensa de licitação — R$ 1,150 — PRATI, DONADUZZI & CIA LTDA |
| 26 | 0.250 | 🟢 | Outlier de valor | Valor atípico — ELFA MEDICAMENTOS S.A |
| 27 | 0.250 | 🟢 | Outlier de valor | Valor atípico — VERMAT COMERCIAL LTDA |
| 28 | 0.250 | 🟢 | Outlier de valor | Valor atípico — LOCASEM SERVICOS DE LIMPEZA, MANUTENCAO E ALIMENTA |
| 29 | 0.250 | 🟢 | Outlier de valor | Valor atípico — JD ACO, INDUSTRIA E COMERCIO LTDA. |
| 30 | 0.250 | 🟢 | Outlier de valor | Valor atípico — FRIOVIX COMERCIO DE REFRIGERACAO LTDA |
| 31 | 0.250 | 🟢 | Outlier de valor | Valor atípico — QUIRON PHARMA LTDA |
| 32 | 0.250 | 🟢 | Outlier de valor | Valor atípico — NSA DISTRIBUIDORA DE MEDICAMENTOS LTDA |
| 33 | 0.250 | 🟢 | Outlier de valor | Valor atípico — BRAXTER HOSPITALAR LTDA |
| 34 | 0.250 | 🟢 | Outlier de valor | Valor atípico — MATRIZ CONSTRUCOES E SERVICOS EMPRESARIAIS LTDA |
| 35 | 0.250 | 🟢 | Outlier de valor | Valor atípico — AZOS VIGILANCIA E SEGURANCA LTDA |
| 36 | 0.250 | 🟢 | Outlier de valor | Valor atípico — MULTIPLY SERVICOS DE MANUTENCAO LTDA |
| 37 | 0.250 | 🟢 | Outlier de valor | Valor atípico — BRJ RENT A CAR LTDA |
| 38 | 0.250 | 🟢 | Outlier de valor | Valor atípico — TORSOR CONSULTORIA E GERENCIAMENTO DE OBRAS LTDA |
| 39 | 0.137 | 🟢 | Concentração de fornecedor | Concentração: 4 contratos em 90 dias — TECNOSET INFORMATICA PRODUTOS E |
| 40 | 0.114 | 🟢 | Concentração de fornecedor | Concentração: 3 contratos em 90 dias — SIMPRESS COMERCIO LOCACAO E SER |

---

## Detalhamento — Anomalias com Score ≥ 0,70

### 1. Inexigibilidade de licitação — R$ 45,000,000 — BONUS TRACK ENTRETENIMENTO LTDA

**Tipo:** Inexigibilidade  
**Severidade:** 🔴 ALTA  
**Score:** `██████████████████░░ 89%`  

**Descrição:**  
Contrato de R$ 45,000,000.00 firmado sem licitação competitiva (Inexigibilidade de licitação). Órgão: PREFEITURA MUNICIPAL DO RIO DE JANEIRO - RJ. Objeto: Realização do projeto “Todo Mundo no Rio: 2026, 2027 e 2028”  (“PROJETO”), consistente na realização anual de espetáculo.

**Métricas:**

| Métrica | Valor |
|---------|-------|
| `tipo_contratacao` | inexigibilidade |
| `valor_global` | 45,000,000.00 |
| `unidade` | PREFEITURA MUNICIPAL DO RIO DE JANEIRO - RJ |
| `processo` | 001200.001161/2026-74 |
| `categoria` | Serviços |

**Contratos envolvidos:**

- `42498733000148-2-000297/2026`

**Metodologia:** Detecção por regex em informacao_complementar + objeto (padrões: inexigibilidade). Severidade: alta ≥ R$10,000,000, média ≥ R$1,000,000. Score = base + log10(valor)/40.

> **{NARRATIVA}** — *Substituir pela análise contextual:*  
> *histórico da empresa/fornecedor, decisões judiciais relacionadas,*  
> *comparativos de mercado, contexto político/administrativo,*  
> *documentação adicional identificada nas fontes secundárias.*

---

### 2. Valor atípico — PRODUMIX COMERCIO E SERVICOS LTDA

**Tipo:** Outlier de valor  
**Severidade:** 🔴 ALTA  
**Score:** `██████████████████░░ 88%`  

**Descrição:**  
Contrato de R$ 1,012,000.00 está 15.0× acima do limite IQR da categoria 'Compras' (Q3 + 1,5×IQR = R$ 67,303.78). Z-score: 8.5. Objeto: Aquisição de Abafadores de ruídos, item 1..

**Métricas:**

| Métrica | Valor |
|---------|-------|
| `valor_global` | 1,012,000.00 |
| `upper_fence` | 67,303.78 |
| `zscore` | 8.51 |
| `multiplicador_fence` | 15.04 |
| `n_categoria` | 174 |
| `media_categoria` | 39,970.42 |

**Contratos envolvidos:**

- `42498733000148-2-000036/2026`

**Metodologia:** IQR por categoria (n=174). Q1=R$1,696, Q3=R$27,939, IQR=R$26,243, fence=R$67,304. Z-score=8.5 (média=R$39,970, DP=R$114,175).

> **{NARRATIVA}** — *Substituir pela análise contextual:*  
> *histórico da empresa/fornecedor, decisões judiciais relacionadas,*  
> *comparativos de mercado, contexto político/administrativo,*  
> *documentação adicional identificada nas fontes secundárias.*

---

### 3. Contrato emergencial — R$ 12,928,979 — AZOS VIGILANCIA E SEGURANCA LTDA

**Tipo:** Emergência  
**Severidade:** 🔴 ALTA  
**Score:** `██████████████████░░ 88%`  

**Descrição:**  
Contrato de R$ 12,928,978.62 firmado sem licitação competitiva (Contrato emergencial). Órgão: PREFEITURA MUNICIPAL DO RIO DE JANEIRO - RJ. Objeto: Prestação de serviços de vigilância patrimonial desarmada..

**Métricas:**

| Métrica | Valor |
|---------|-------|
| `tipo_contratacao` | emergencia |
| `valor_global` | 12,928,978.62 |
| `unidade` | PREFEITURA MUNICIPAL DO RIO DE JANEIRO - RJ |
| `processo` | 000700.000839/2026-06 |
| `categoria` | Serviços |

**Contratos envolvidos:**

- `42498733000148-2-000175/2026`

**Metodologia:** Detecção por regex em informacao_complementar + objeto (padrões: emergencia). Severidade: alta ≥ R$5,000,000, média ≥ R$500,000. Score = base + log10(valor)/40.

> **{NARRATIVA}** — *Substituir pela análise contextual:*  
> *histórico da empresa/fornecedor, decisões judiciais relacionadas,*  
> *comparativos de mercado, contexto político/administrativo,*  
> *documentação adicional identificada nas fontes secundárias.*

---

### 4. Dispensa de licitação — R$ 8,018,696 — MATRIZ CONSTRUCOES E SERVICOS EMPRESARIAIS LTDA

**Tipo:** Dispensa  
**Severidade:** 🔴 ALTA  
**Score:** `█████████████████░░░ 87%`  

**Descrição:**  
Contrato de R$ 8,018,696.04 firmado sem licitação competitiva (Dispensa de licitação). Órgão: PREFEITURA MUNICIPAL DO RIO DE JANEIRO - RJ. Objeto: Prestação de Serviços de Apoio Operacional e Monitoramento de Políticas Habitacionais..

**Métricas:**

| Métrica | Valor |
|---------|-------|
| `tipo_contratacao` | dispensa |
| `valor_global` | 8,018,696.04 |
| `unidade` | PREFEITURA MUNICIPAL DO RIO DE JANEIRO - RJ |
| `processo` | 002200.000048/2025-53 |
| `categoria` | Mão de Obra |

**Contratos envolvidos:**

- `42498733000148-2-000122/2026`

**Metodologia:** Detecção por regex em informacao_complementar + objeto (padrões: dispensa). Severidade: alta ≥ R$1,000,000, média ≥ R$200,000. Score = base + log10(valor)/40.

> **{NARRATIVA}** — *Substituir pela análise contextual:*  
> *histórico da empresa/fornecedor, decisões judiciais relacionadas,*  
> *comparativos de mercado, contexto político/administrativo,*  
> *documentação adicional identificada nas fontes secundárias.*

---

### 5. Valor atípico — GAIA COMERCIO E PRODUTOS QUIMICOS LTDA

**Tipo:** Outlier de valor  
**Severidade:** 🔴 ALTA  
**Score:** `█████████████████░░░ 83%`  

**Descrição:**  
Contrato de R$ 816,864.00 está 12.1× acima do limite IQR da categoria 'Compras' (Q3 + 1,5×IQR = R$ 67,303.78). Z-score: 6.8. Objeto: AQUISIÇÃO DE POLICLORETO DE ALUMÍNIO VISANDO ATENDER ÀS NECESSIDADES DA ESTAÇÃO DE TRATAMENTO DE ÁGUA DO PARQUE AMBIENTA.

**Métricas:**

| Métrica | Valor |
|---------|-------|
| `valor_global` | 816,864.00 |
| `upper_fence` | 67,303.78 |
| `zscore` | 6.80 |
| `multiplicador_fence` | 12.14 |
| `n_categoria` | 174 |
| `media_categoria` | 39,970.42 |

**Contratos envolvidos:**

- `42498733000148-2-000234/2026`

**Metodologia:** IQR por categoria (n=174). Q1=R$1,696, Q3=R$27,939, IQR=R$26,243, fence=R$67,304. Z-score=6.8 (média=R$39,970, DP=R$114,175).

> **{NARRATIVA}** — *Substituir pela análise contextual:*  
> *histórico da empresa/fornecedor, decisões judiciais relacionadas,*  
> *comparativos de mercado, contexto político/administrativo,*  
> *documentação adicional identificada nas fontes secundárias.*

---

### 6. Concentração: 4 contratos em 90 dias — CONSTRUTORA ENTRE OS RIOS LTDA

**Tipo:** Concentração de fornecedor  
**Severidade:** 🔴 ALTA  
**Score:** `████████████████░░░░ 82%`  

**Descrição:**  
CONSTRUTORA ENTRE OS RIOS LTDA recebeu 4 contratos entre 2026-03-09 e 2026-06-07 (90 dias), totalizando R$ 86,480,775.04. Órgãos: PREFEITURA MUNICIPAL DO RIO DE JANEIRO - RJ. Categorias: Obras, Serviços de Engenharia.

**Métricas:**

| Métrica | Valor |
|---------|-------|
| `qtd_contratos_janela` | 4 |
| `total_janela` | 86,480,775.04 |
| `janela_inicio` | 2026-03-09 |
| `janela_fim` | 2026-06-07 |
| `categorias` | Obras, Serviços de Engenharia |
| `orgaos` | PREFEITURA MUNICIPAL DO RIO DE JANEIRO - RJ |

**Contratos envolvidos:**

- `42498733000148-2-000120/2026`
- `42498733000148-2-000236/2026`
- `42498733000148-2-000250/2026`
- `42498733000148-2-000288/2026`

**Metodologia:** Janela deslizante de 90 dias. Score = 0,30×(qtd/10) + 0,70×(total/R$50M). Filtros: ≥3 contratos e total ≥ R$1,000,000.

> **{NARRATIVA}** — *Substituir pela análise contextual:*  
> *histórico da empresa/fornecedor, decisões judiciais relacionadas,*  
> *comparativos de mercado, contexto político/administrativo,*  
> *documentação adicional identificada nas fontes secundárias.*

---

### 7. Valor atípico — PRONTO EXPRESS LOGISTICA SA

**Tipo:** Outlier de valor  
**Severidade:** 🔴 ALTA  
**Score:** `████████████████░░░░ 80%`  

**Descrição:**  
Contrato de R$ 49,640,000.00 está 54.6× acima do limite IQR da categoria 'Serviços' (Q3 + 1,5×IQR = R$ 908,588.71). Z-score: 5.9. Objeto: Contratação de empresa especializada para prestação de serviço de operação logística, considerados o armazenamento, cont.

**Métricas:**

| Métrica | Valor |
|---------|-------|
| `valor_global` | 49,640,000.00 |
| `upper_fence` | 908,588.71 |
| `zscore` | 5.89 |
| `multiplicador_fence` | 54.63 |
| `n_categoria` | 97 |
| `media_categoria` | 2,421,406.70 |

**Contratos envolvidos:**

- `42498733000148-2-000117/2026`

**Metodologia:** IQR por categoria (n=97). Q1=R$7,658, Q3=R$368,030, IQR=R$360,372, fence=R$908,589. Z-score=5.9 (média=R$2,421,407, DP=R$8,017,724).

> **{NARRATIVA}** — *Substituir pela análise contextual:*  
> *histórico da empresa/fornecedor, decisões judiciais relacionadas,*  
> *comparativos de mercado, contexto político/administrativo,*  
> *documentação adicional identificada nas fontes secundárias.*

---

### 8. Valor atípico — BONUS TRACK ENTRETENIMENTO LTDA

**Tipo:** Outlier de valor  
**Severidade:** 🔴 ALTA  
**Score:** `████████████████░░░░ 78%`  

**Descrição:**  
Contrato de R$ 45,000,000.00 está 49.5× acima do limite IQR da categoria 'Serviços' (Q3 + 1,5×IQR = R$ 908,588.71). Z-score: 5.3. Objeto: Realização do projeto “Todo Mundo no Rio: 2026, 2027 e 2028”  (“PROJETO”), consistente na realização anual de espetáculo.

**Métricas:**

| Métrica | Valor |
|---------|-------|
| `valor_global` | 45,000,000.00 |
| `upper_fence` | 908,588.71 |
| `zscore` | 5.31 |
| `multiplicador_fence` | 49.53 |
| `n_categoria` | 97 |
| `media_categoria` | 2,421,406.70 |

**Contratos envolvidos:**

- `42498733000148-2-000297/2026`

**Metodologia:** IQR por categoria (n=97). Q1=R$7,658, Q3=R$368,030, IQR=R$360,372, fence=R$908,589. Z-score=5.3 (média=R$2,421,407, DP=R$8,017,724).

> **{NARRATIVA}** — *Substituir pela análise contextual:*  
> *histórico da empresa/fornecedor, decisões judiciais relacionadas,*  
> *comparativos de mercado, contexto político/administrativo,*  
> *documentação adicional identificada nas fontes secundárias.*

---

## Próximos Passos

1. **Concentração: 4 contratos em 90 dias — CONSTRUTORA ENTRE OS ** — Verificar se os 4 contratos vieram de licitações separadas ou de processo único. Cruzar com Portal da Transparência da Prefeitura (empenhos realizados).
2. **Inexigibilidades de alto valor** — Verificar justificativas publicadas no Diário Oficial do Município. Comparar com valores praticados em outros municípios para serviços equivalentes.
3. **Contratos emergenciais** — Verificar se a situação emergencial foi formalmente declarada e publicada. Avaliar se o prazo de vigência é compatível com a natureza da emergência declarada.
4. **Outliers de valor** — Cruzar com o orçamento estimado da licitação de referência. Verificar histórico do fornecedor no PNCP em outros municípios e no TCE/TCM-RJ.
5. **Ampliar coleta** — Expandir base para 2019–2022 para construir série histórica e comparar padrões entre gestões municipais.
6. **Cruzar fontes** — Portal da Transparência da Prefeitura do Rio (empenhos vs. contratos assinados) + TCM-RJ (julgamentos e irregularidades).
7. **Monitoramento contínuo** — Configurar coleta semanal para detectar novos contratos nas categorias de risco já identificadas.

---

*Relatório gerado pelo Sentinela RJ — monitoramento de contratos públicos municipais*  
*Dados: PNCP | Análise automática: Sentinela RJ v0.1*